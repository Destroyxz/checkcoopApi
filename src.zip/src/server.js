import 'dotenv/config';
import express from 'express';
import cookieParser from 'cookie-parser';
import cors from 'cors';
import bcrypt from 'bcrypt';
import knex from './db.js';

import verifyToken from './middleware/verifytoken.js';
import authRouter from './routes/auth.js';
import dashboardRouter from './routes/dashboard.js';
import usersRouter from './routes/users.js';

// Generación de hashes de superadmins
const PLAINS = [
  { name: 'gabrielDev', pass: 'ElPepeEteSetch' },
  { name: 'FranciscoDev', pass: 'contraPolloFran' }
];

(async () => {
  const saltRounds = 12;
  console.log('=== Hashes de superadmins ===');
  for (const { name, pass } of PLAINS) {
    const hash = await bcrypt.hash(pass, saltRounds);
    console.log(`${name}: ${hash}`);
  }
})();

const app = express();
const PORT = process.env.PORT || 3000;

// Middlewares globales
app.use(express.json());
app.use(cookieParser());
app.use(cors({
  origin: process.env.CLIENT_URL || 'http://localhost:4200',
  methods: ['GET','POST','PUT','DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

// 1️⃣ Rutas PÚBLICAS (sin token)
app.use('/', authRouter);

// 2️⃣ Middleware de verificación de token para rutas protegidas
app.use(verifyToken);

// 3️⃣ Rutas PROTEGIDAS
app.use('/', dashboardRouter);
app.use('/users', usersRouter);

// 4️⃣ Ruta raíz protegida GET /
app.get('/', (req, res) => {
  res.json({
    message: 'API raíz protegida: estás autenticado',
    user: req.user
  });
});

// 5️⃣ 404 para cualquier otro endpoint
app.use((req, res) => {
  res.status(404).json({ message: 'Endpoint no encontrado' });
});

// 6️⃣ Manejador de errores genérico
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ message: 'Error interno del servidor' });
});

app.listen(PORT, () => {
  console.log(`API escuchando en puerto ${PORT}`);
});